export class PingBusiness {
    public ping = async () => {
        const response = {
            message: "Pong!"
        }
        
        return response
    }
}