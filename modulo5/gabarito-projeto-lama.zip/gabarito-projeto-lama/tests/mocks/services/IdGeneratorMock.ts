export class IdGeneratorMock {
    public generate = (): string => {
        return "id-mock"
    }
}